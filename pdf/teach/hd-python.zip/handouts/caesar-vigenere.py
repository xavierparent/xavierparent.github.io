# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 15:30:33 2019

@author: xavier.parent
"""



## from character to ascii code

ord("A")
ord("a")
ord("1")

## from ascii code to character

chr(ord("A"))

###############
## Caesar cypher
###############

string = input('Enter Input: ')
shift = int(input('Enter a KEY (1-25): '))

def encrypt(string, shift):
 
  cipher = ''
  for char in string: 
    if char == ' ':
      cipher = cipher + char
    elif  char.isupper():
      cipher = cipher + chr((ord(char) + shift - 65) % 26 + 65)
    else:
      cipher = cipher + chr((ord(char) + shift - 97) % 26 + 97)
  
  return cipher
 
encrypted=encrypt(string,shift)
print(encrypted)

#print(chr((ord("H") + 3 - 65) % 26 + 65)) # We get K

#ord("H"): ascii value of H
#ord("H") + 3 : shift by 3
#ord("H") + 3 -65  : A starts at 65
# ord("H") + 3 -65 % 26 : in case the letter is shifted past the alphabet
#ord("H") + 3 -65 % 26 + 65 : to get the ascii value back
#chr : to get the corresponding letter

#print(chr((ord("h") + 3 - 97) % 26 + 97)) # We get k
#print(chr((ord("K") - shift - 65) % 26 + 65))
### decrypting

def uncipher(cipher,shift):
    
  uncipher = ''
  for char in cipher: 
    if char == ' ':
      uncipher = uncipher + char
    elif  char.isupper():
      uncipher = uncipher + chr((ord(char) - shift - 65) % 26 + 65)
    else:
      uncipher = uncipher + chr((ord(char) - shift - 97) % 26 + 97)
  
  return uncipher

decrypted=uncipher(encrypted,shift)
    
print("Original message : ",string)
print("Crypted message  : ",encrypted)
print("Decrypted message : ",decrypted)

###################
## Brute force attack on Caesar
###################

def uncipher(cipher,shift): # we repeat the previous definition
    
  uncipher = ''
  for char in cipher: 
    if char == ' ':
      uncipher = uncipher + char
    elif  char.isupper():
      uncipher = uncipher + chr((ord(char) - shift - 65) % 26 + 65)
    else:
      uncipher = uncipher + chr((ord(char) - shift - 97) % 26 + 97)
  
  return uncipher


cipher="Khoor zruog"
for shift in range(1,26): ##### we try all the possible shifts
    print("Key :",shift)
    print("decrypted message :")
    print(uncipher(cipher,shift))


########
## VIGENERE--for simplicity we work we upper-cases only
########    

## CRYPTING
  # chr((ord(key)+ord(char))%26 + 65) 
# to crypt a given letter of the plain text using the relevant letter of the key
    
cryptLetter = lambda key, char: chr(((ord(key)+ord(char)))%26 + 65) 

def cryptString(myString, key):
    result = ''
    for ind, char in enumerate(myString):
        result += cryptLetter(key[ind%len(key)], char)
    return result


cryptString("ATTACKATDAWN", "LEMON")

## To check what the diffierent building block do

myString="ATTACKATDAWN"
key="LEMON"
for ind, char in enumerate(myString):
    print(ind,char)
    print(key[ind%len(key)])


## DECRYPTING

# to decrypt a given letter of the ciphertext message using the relevant letter of the key

uncryptLetter = lambda key, char: chr((ord(char) - ord(key)) % 26 + 65) 

def uncryptString(myString, key):
    result = ''
    for ind, char in enumerate(myString):
        result += uncryptLetter(key[ind%len(key)],char)
    return result

uncryptString("LXFOPVEFRBHR","LEMON")


 
 


    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
